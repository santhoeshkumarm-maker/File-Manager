package com.example.filemanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { if (granted) FileManager() else AccessScreen() } }
    }

    override fun onResume() { super.onResume(); granted = hasAccess() }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); granted = hasAccess()
    }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == 0

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30)
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
    }

    @Composable
    private fun AccessScreen() {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("File access is needed to browse your storage.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = { askAccess() }) { Text("Grant access") }
        }
    }

    private fun uniqueTarget(d: File, n: String): File {
        var t = File(d, n); var i = 1
        val base = n.substringBeforeLast('.'); val ext = if (n.contains('.')) "." + n.substringAfterLast('.') else ""
        while (t.exists()) { t = File(d, "$base ($i)$ext"); i++ }
        return t
    }

    private fun open(f: File) = try {
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
    } catch (e: Exception) {}

    private fun share(fs: List<File>) = try {
        val uris = ArrayList(fs.filter { it.isFile }.map { FileProvider.getUriForFile(this, "$packageName.fp", it) })
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
    } catch (e: Exception) {}

    private fun info(f: File): String {
        val size = if (f.isDirectory) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else f.length()
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(f.lastModified()))
        return "${f.name}\n${f.absolutePath}\nSize: ${Formatter.formatFileSize(this, size)}\nModified: $date"
    }

    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun FileManager() {
        val root = Environment.getExternalStorageDirectory()
        var dir by remember { mutableStateOf(root) }
        var tick by remember { mutableIntStateOf(0) }
        var sort by remember { mutableStateOf("Name") }
        var hidden by remember { mutableStateOf(false) }
        var query by remember { mutableStateOf("") }
        var searching by remember { mutableStateOf(false) }
        val selected = remember { mutableStateListOf<File>() }
        var clip by remember { mutableStateOf<List<File>>(emptyList()) }
        var cut by remember { mutableStateOf(false) }
        var dialog by remember { mutableStateOf<String?>(null) }
        var text by remember { mutableStateOf("") }
        var menu by remember { mutableStateOf(false) }

        val files = remember(dir, tick, sort, hidden, query) {
            val base = if (query.isBlank()) dir.listFiles()?.asList() ?: emptyList()
            else dir.walkTopDown().maxDepth(6).filter { it != dir && it.name.contains(query, true) }.toList()
            val order: Comparator<File> = when (sort) {
                "Size" -> compareBy<File> { it.length() }
                "Date" -> compareByDescending<File> { it.lastModified() }
                else -> compareBy<File, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
            }
            base.filter { hidden || !it.name.startsWith(".") }
                .sortedWith(compareByDescending<File> { it.isDirectory }.then(order))
        }

        fun refresh() { selected.clear(); tick++ }

        BackHandler(selected.isNotEmpty() || searching || dir != root) {
            when {
                selected.isNotEmpty() -> selected.clear()
                searching -> { searching = false; query = "" }
                else -> dir.parentFile?.let { dir = it }
            }
        }

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                if (selected.isEmpty()) {
                    Text(dir.absolutePath, Modifier.widthIn(min = 200.dp).padding(8.dp))
                    Box {
                        TextButton({ menu = true }) { Text("Menu") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("New folder") }, { menu = false; text = ""; dialog = "new" })
                            DropdownMenuItem({ Text("Search") }, { menu = false; searching = true })
                            if (clip.isNotEmpty()) DropdownMenuItem({ Text("Paste (${clip.size})") }, {
                                menu = false
                                clip.forEach { f ->
                                    val t = uniqueTarget(dir, f.name)
                                    if (f.isDirectory && t.path.startsWith(f.path + "/")) return@forEach
                                    if (cut) { if (!f.renameTo(t)) { f.copyRecursively(t); f.deleteRecursively() } }
                                    else f.copyRecursively(t)
                                }
                                if (cut) clip = emptyList(); refresh()
                            })
                            listOf("Name", "Size", "Date").forEach { s ->
                                DropdownMenuItem({ Text("Sort by $s" + if (sort == s) " ✔" else "") }, { sort = s; menu = false })
                            }
                            DropdownMenuItem({ Text((if (hidden) "Hide" else "Show") + " hidden files") }, { hidden = !hidden; menu = false })
                        }
                    }
                } else {
                    Text("${selected.size} selected", Modifier.padding(8.dp))
                    TextButton({ clip = selected.toList(); cut = false; selected.clear() }) { Text("Copy") }
                    TextButton({ clip = selected.toList(); cut = true; selected.clear() }) { Text("Cut") }
                    TextButton({ dialog = "delete" }) { Text("Delete") }
                    if (selected.size == 1) {
                        TextButton({ text = selected[0].name; dialog = "rename" }) { Text("Rename") }
                        TextButton({ dialog = "info" }) { Text("Info") }
                    }
                    TextButton({ share(selected.toList()) }) { Text("Share") }
                    TextButton({ selected.clear(); selected.addAll(files) }) { Text("All") }
                }
            }
            if (searching) OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                singleLine = true, label = { Text("Search in this folder") })
            Text("Free: ${Formatter.formatFileSize(this@MainActivity, root.freeSpace)} of ${Formatter.formatFileSize(this@MainActivity, root.totalSpace)}",
                Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelSmall)
            LazyColumn(Modifier.weight(1f)) {
                items(files, key = { it.absolutePath }) { f ->
                    val sel = f in selected
                    fun toggle() { if (sel) selected.remove(f) else selected.add(f) }
                    ListItem(
                        headlineContent = { Text((if (sel) "✔ " else "") + f.name) },
                        supportingContent = {
                            Text(if (f.isDirectory) "${f.listFiles()?.size ?: 0} items"
                            else Formatter.formatFileSize(this@MainActivity, f.length()) + " • " +
                                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(f.lastModified())))
                        },
                        leadingContent = { Text(if (f.isDirectory) "📁" else "📄") },
                        colors = ListItemDefaults.colors(containerColor =
                            if (sel) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface),
                        modifier = Modifier.combinedClickable(onLongClick = { toggle() }, onClick = {
                            when {
                                selected.isNotEmpty() -> toggle()
                                f.isDirectory -> { dir = f; query = ""; searching = false }
                                else -> open(f)
                            }
                        })
                    )
                }
            }
        }

        dialog?.let { d ->
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text(when (d) { "new" -> "New folder"; "rename" -> "Rename"; "delete" -> "Delete ${selected.size} item(s)?"; else -> "Details" }) },
                text = {
                    when (d) {
                        "new", "rename" -> OutlinedTextField(text, { text = it }, singleLine = true)
                        "info" -> Text(info(selected[0]))
                        else -> Text("This cannot be undone.")
                    }
                },
                confirmButton = {
                    TextButton({
                        when (d) {
                            "new" -> if (text.isNotBlank()) File(dir, text.trim()).mkdirs()
                            "rename" -> { val f = selected[0]; val t = File(f.parentFile, text.trim())
                                if (text.isNotBlank() && !t.exists()) f.renameTo(t) }
                            "delete" -> selected.forEach { it.deleteRecursively() }
                        }
                        dialog = null; refresh()
                    }) { Text("OK") }
                },
                dismissButton = { TextButton({ dialog = null }) { Text("Cancel") } }
            )
        }
    }
}
